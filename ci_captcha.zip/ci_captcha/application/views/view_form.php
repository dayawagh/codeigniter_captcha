<!DOCTYPE html>
<html>
<head>
    <title>Google Recaptcha Code in Codeigniter 3 - ItSolutionStuff.com</title>
    
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
  
<div class="container">
    <div class="card">
        <div class="card-header">
            Captcha Code in Codeigniter 3
        </div>
        <div class="card-body">
            <form action="<?php echo base_url(); ?>index.php/welcome/formPost" method="post" enctype="multipart/form-data">
                <div class="text-danger"><strong><?php //echo $this->session->flashdata('error')?></strong></div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="text" class="form-control" autocomplete="off" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
  
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" autocomplete="off" id="exampleInputPassword1" placeholder="Password">
                </div>
                    
                <div id="cap_one" class="ci-captcha" <?php echo $this->config->item('google_key') ?>>
				<?php echo $captcha; ?>
				</div>

				<div class="form-group">
                    <label for="captcha">Enter captcha above captcha code here</label>
                    <input type="text" class="form-control" name="captcha" id="captcha" autocomplete="off" placeholder="Enter captcha above number">
					<div id="captcha_error">
						<?php echo isset($_SESSION['error'])?$_SESSION['error']:''; ?>
					</div>
					<input type="hidden" name="captcha_image" id="captcha_image">
				</div>
                 
                <br/>
                <button class="btn btn-success">Login</button>
            </form>
        </div>
    </div>
</div>
<script>
$(document).ready(function () {
	var captcha_image = $('#ci_captcha_id').attr('src');
	$('#captcha_image').val(captcha_image);
});
</script>  
</body> 
</html>
